package pansong291.xposed.quickenergy.hook;

public class ClassMember {
    public static final String PACKAGE_NAME = "com.eg.android.AlipayGphone";
    public static final String CURRENT_USING_ACTIVITY = "com.eg.android.AlipayGphone.AlipayLogin";
    public static final String CURRENT_USING_SERVICE = "com.alipay.dexaop.power.RuntimePowerService";
    public static final String com_alipay_mobile_nebulaappproxy_api_rpc_H5AppRpcUpdate = "com.alipay.mobile.nebulaappproxy.api.rpc.H5AppRpcUpdate";
    public static final String matchVersion = "matchVersion";
    public static final String com_alipay_mobile_h5container_api_H5Page = "com.alipay.mobile.h5container.api.H5Page";
    public static final String com_alibaba_fastjson_JSONObject = "com.alibaba.fastjson.JSONObject";
    public static final String com_alipay_mobile_nebulaappproxy_api_rpc_H5RpcUtil = "com.alipay.mobile.nebulaappproxy.api.rpc.H5RpcUtil";
    public static final String rpcCall = "rpcCall";
    public static final String getResponse = "getResponse";

}
